package com.cmt.dao;

public class AccountNotFoundException extends Exception{

}
