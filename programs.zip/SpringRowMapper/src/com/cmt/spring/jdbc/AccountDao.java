package com.cmt.spring.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class AccountDao {

	private JdbcTemplate template;  
	  
	public void setTemplate(JdbcTemplate template) {  
	    this.template = template;  
	}
	
	public List<Account> getAccountRowMapper(){  
		 return template.query("select * from ACCOUNT",new RowMapper<Account>(){  
		    @Override  
		    public Account mapRow(ResultSet rs, int rownumber) throws SQLException {  
		    	Account e=new Account();  
		        e.setAccno(rs.getInt(1));  
		        e.setName(rs.getString(2));  
		        e.setBalance(rs.getInt(3));  
		        return e;  
		    }  
		    });  
		}  
	
}
