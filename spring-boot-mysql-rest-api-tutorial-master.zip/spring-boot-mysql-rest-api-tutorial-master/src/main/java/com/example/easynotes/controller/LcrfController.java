package com.example.easynotes.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.easynotes.model.LcrfApi;
import com.example.easynotes.repository.LcrfRepo;

@RestController
@RequestMapping("/LCRF")
public class LcrfController {

	List<LcrfApi> lcrf = new ArrayList<LcrfApi>();
	
	@Autowired
	LcrfRepo lcrfRepo;
	
	@GetMapping("/allData")
	public List<LcrfApi> getAll()
	{
		lcrf = lcrfRepo.findAll();
		
		return lcrf;
	}
	
	@GetMapping("/allData/{sellerId}")
	public LcrfApi getSellerDetail(@PathVariable(value = "sellerId")Long sellerId)
	{
		
		return lcrfRepo.getSellerDataById(sellerId);
	}
	
	@GetMapping("/allData/{sellerId}/{sellerName}")
	public List<LcrfApi> getDataByIdAndName(@PathVariable(value = "sellerId")Long sellerId,@PathVariable(value = "sellerId")String sellerName)
	{
		
		lcrf = lcrfRepo.findDataBySellerIDAndSellerName(sellerId, sellerName);
		return lcrf;	
	}
}
