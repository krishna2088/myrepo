package com.cmt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;


public class AccountDAO implements AccountDAOInterface{
	
	private DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	public Account getAccount(int accno) throws AccountNotFoundException, DataAccessException{
		
		Account acc = null;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try{
			
			con = dataSource.getConnection();
			ps = con.prepareStatement("SELECT * FROM ACCOUNT WHERE ACCNO=?");
			ps.setInt(1, accno);
			rs = ps.executeQuery();
			if(rs.next()){
				
				acc = new Account();
				acc.setAccno(rs.getInt(1));
				acc.setName(rs.getString(2));
				acc.setBalance(rs.getFloat(3));
				
			}else{
				throw new AccountNotFoundException();
			}
			
		}catch(SQLException e){
			
			throw new DataAccessException();
		}
		finally{
			
			try{
				
				if(rs != null)	rs.close();
				if(ps != null)	ps.close();
				if(con != null)	con.close();
			}catch(Exception e){
				
				e.printStackTrace();
			}
		}
		
		return acc;
	}
}
