package com.cmt.spring;

public class ServiceController {
	CustomerService service; //dependency

	public ServiceController() {
	}

	public ServiceController(CustomerService service) {
		this.service = service;
	}

	public void setService(CustomerService service) {
		this.service = service;
	}

	public void handleRequest() {
		service.processService();
		System.out.println("handleRequest completed");
	}
}
