package com.cmt.map;

import java.util.HashMap;
import org.hibernate.*;
import org.hibernate.cfg.*;

public class StoreTest {
	public static void main(String[] args) {
		Session session = new Configuration().configure().buildSessionFactory()
				.openSession();
		Transaction tx = session.beginTransaction();

		HashMap<String, String> map1 = new HashMap<String, String>();
		map1.put("java is a programming language", "MGR");
		map1.put("java is a platform", "Jayalalitha");

		HashMap<String, String> map2 = new HashMap<String, String>();
		map2.put("servlet technology is a server side programming",
				"John Milton");
		map2.put("Servlet is an Interface", "Rajini");
		map2.put("Servlet is a package", "Kanimouli");

		Question question1 = new Question("What is java?", "Sruthi", map1);
		Question question2 = new Question("What is servlet?", "Kamal", map2);

		session.persist(question1);
		session.persist(question2);

		tx.commit();
		session.close();
		System.out.println("successfully stored");
	}
}