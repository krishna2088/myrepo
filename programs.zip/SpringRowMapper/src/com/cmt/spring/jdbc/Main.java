package com.cmt.spring.jdbc;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		AccountDao dao = ctx.getBean("dao", AccountDao.class);
		List<Account> list = dao.getAccountRowMapper();

		for (Account a : list)
			System.out.println(a );
	}

}
