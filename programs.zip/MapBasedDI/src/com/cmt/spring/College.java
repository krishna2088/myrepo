package com.cmt.spring;

import java.util.Map;

public class College {
	
	private String name;
	private  Map<Integer,Student> students;
	
	public College(){}
	
	public College(String name){
		this.name = name;
	}
	
	public Map<Integer,Student> getStudents() {
		return students;
	}
	public void setStudents(Map<Integer,Student> students) {
		this.students = students;
	}
}
