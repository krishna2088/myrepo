package com.example.easynotes.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="HSBC")
public class LcrfApi {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private Long id;
	
	@Column(name="Seller_Id")
	private Long sellerId;
	
	@Column(name="Seller_Name")
	private String sellerName;
	
	@Column(name="Buyer_Id")
	private int buyerId;
	
	@Column(name="Buyer_Name")
	private String buyerName;
	
	@Column(name="Login_Date")
	private Date loginDate;
	
	@Column(name="Amount")
	private int amount;
	
	
	
	public LcrfApi() {
		super();
	}



	public LcrfApi(Long id, Long sellerId, String sellerName, int buyerId, String buyerName, Date loginDate, int amount) {
		super();
		this.id = id;
		this.sellerId = sellerId;
		this.sellerName = sellerName;
		this.buyerId = buyerId;
		this.buyerName = buyerName;
		this.loginDate = loginDate;
		this.amount = amount;
	}



	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public Long getSellerId() {
		return sellerId;
	}



	public void setSellerId(Long sellerId) {
		this.sellerId = sellerId;
	}



	public String getSellerName() {
		return sellerName;
	}



	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}



	public int getBuyerId() {
		return buyerId;
	}



	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}



	public String getBuyerName() {
		return buyerName;
	}



	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}



	public Date getLoginDate() {
		return loginDate;
	}



	public void setLoginDate(Date loginDate) {
		this.loginDate = loginDate;
	}



	public int getAmount() {
		return amount;
	}



	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	
	
	
}
