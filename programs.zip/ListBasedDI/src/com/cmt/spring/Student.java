package com.cmt.spring;

public class Student {

	private int rollno;
	private  String name;
	
	public Student(int rollno, String name) {
		this.rollno = rollno;
		this.name = name;
	}
	
	public void displayStudentDetails(){
		System.out.println("Roll NO: "+ rollno +", Name: "+name);
	}
}
