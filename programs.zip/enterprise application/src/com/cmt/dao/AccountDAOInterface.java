package com.cmt.dao;

public interface AccountDAOInterface {
		public Account getAccount(int accno) throws AccountNotFoundException, DataAccessException;
}
