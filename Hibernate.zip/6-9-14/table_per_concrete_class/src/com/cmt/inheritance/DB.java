package com.cmt.inheritance;

public class DB {

	/*
	 * create table Employee1 ( id number(10), name varchar2(50) );
	 * 
	 * create table Regular_Employee ( id number(10), name varchar2(50), salary
	 * number(10), bonus varchar2(50) );
	 * 
	 * create table Contract_Employee ( id number(10), name varchar2(50),
	 * pay_per_hour number(10), contract_period varchar2(50) );
	 */

}
