package com.cmt.spring;

import java.util.Properties;

public class PropertyBean {

	Properties properties; // dependency

	public Properties getProperties() {
		return properties;
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}
	
}
