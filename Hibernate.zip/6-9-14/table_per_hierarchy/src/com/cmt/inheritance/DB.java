package com.cmt.inheritance;

public class DB {
/*

create table employee (
id number(10),
type	varchar2(10),
name	varchar2(10),
salary	number(10),
bonus	varchar2(10),
pay_per_hour number(10),
contract_period  varchar2(10)
);

 */
}
