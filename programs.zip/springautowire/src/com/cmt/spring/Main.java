package com.cmt.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

class Main{
	public static void main(String[] arg){
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		ServiceController cc=(ServiceController)context.getBean("cc");
			cc.handleRequest();
		 System.out.println("------");
	
	}
}
