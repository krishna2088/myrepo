package com.cmt.spring;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	static int count = 0;
	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		College college= applicationContext.getBean("college", College.class);
		Map<Integer, Student>	students = college.getStudents();
		
		Set<Integer> keys = students.keySet();
		
		for(Integer key : keys){
			Student s = (Student)students.get(key);
			s.displayStudentDetails();
			
			count++;
		}
		System.out.println("count :"+ count);
	}
}
