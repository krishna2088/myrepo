package com.jackrutorial.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Defect", schema = "jackrutorial")
public class Defect {
 
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "defect_id", unique = true)
	private int DefectId;
	
	@Column(name = "category")
	private String Category;
	
	@Column(name = "Chgstatus")
	private String changeStatus;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "priority")
	private int priority;
	
	@Column(name = "status")
	private String status;

	public Defect()
	{
		
	}
	
	public Defect(int defectId, String category, String changeStatus, String description, int priority, String status) {
		super();
		DefectId = defectId;
		Category = category;
		this.changeStatus = changeStatus;
		this.description = description;
		this.priority = priority;
		this.status = status;
	}

	public int getDefectId() {
		return DefectId;
	}

	public void setDefectId(int defectId) {
		DefectId = defectId;
	}

	public String getCategory() {
		return Category;
	}

	public void setCategory(String category) {
		Category = category;
	}

	public String getChangeStatus() {
		return changeStatus;
	}

	public void setChangeStatus(String changeStatus) {
		this.changeStatus = changeStatus;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	
	
 
}