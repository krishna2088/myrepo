package com.cmt.spring;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		PropertyBean propertyBean= applicationContext.getBean("c", PropertyBean.class);
		
		Properties p = propertyBean.getProperties();
		Set<String> keys = p.stringPropertyNames();
		for(String key : keys){
			System.out.println(key +": "+ p.getProperty(key));
		}
	}
}
