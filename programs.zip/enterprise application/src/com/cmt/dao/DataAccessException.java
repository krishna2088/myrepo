package com.cmt.dao;

public class DataAccessException extends Exception{

}
