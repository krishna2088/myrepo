package com.cmt.spring.jdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;


public class Main {
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		JdbcTemplate template = context.getBean("jdbcTemplete",JdbcTemplate.class);
		/*int i = template.update("insert into  account values(1,'Rama',3000)");
		System.out.println(i);*/
		
		Account acc = (Account) template.queryForObject("select *from account where balance > 1000", new BeanPropertyRowMapper(Account.class));
		System.out.println("acc no: "+acc.getAccno()+" "+acc.getName());

	
		
	}

}
/*
Account acc = template.queryForObject("select *from account where balance =100", new BeanPropertyRowMapper(Account.class));
		System.out.println("acc no: "+acc.getAccno()+" "+acc.getName());

*/