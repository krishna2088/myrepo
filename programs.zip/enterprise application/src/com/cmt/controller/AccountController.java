package com.cmt.controller;


import javax.servlet.http.HttpServletRequest;

import com.cmt.dao.AccountNotFoundException;
import com.cmt.service.AccountService;
import com.cmt.service.ProcessingException;

public class AccountController {
		AccountService service;  //Dependency through xml config.

		public void setService(AccountService service) {
			this.service = service;
		}
		
		public void execute(HttpServletRequest request)throws AccountNotFoundException, ProcessingException{
			int accno = Integer.parseInt(request.getParameter("accno"));
			try{
				
				float interest = service.calculateInterest(accno);
				request.setAttribute("interest", interest);
				
			}catch(AccountNotFoundException e){
				throw e;
				
			}catch(ProcessingException e){
				throw e;
			}
			
		}
}
