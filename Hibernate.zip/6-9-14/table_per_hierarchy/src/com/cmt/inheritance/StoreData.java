package com.cmt.inheritance;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
//import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
//import org.hibernate.service.ServiceRegistry;

public class StoreData {  
	
public static void main(String[] args) { 
	
    /*Configuration cfg=new Configuration();  
    Session session=cfg.configure("hibernate.cfg.xml").buildSessionFactory().openSession();  
      */
	
	/*Configuration configuration = new Configuration().configure();
	
	ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
	SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
	
	Session session = sessionFactory.openSession();*/
	
	String i = null;
	Session session = new Configuration().configure().buildSessionFactory()
			.openSession();
	
	Transaction t = session.beginTransaction();
      
    Employee e1=new Employee();  
    e1.setName("Nandi");  
    
    RegularEmployee e2=new RegularEmployee();  
    e2.setName("Siva");  
    e2.setSalary(50000);  
    e2.setBonus(5);  
      
    ContractEmployee e3=new ContractEmployee();  
    e3.setName("Rajini");  
    e3.setPay_per_hour(1000);  
    e3.setContract_duration("5 hours");  
      
    session.persist(e1);  
    session.persist(e2);  
    session.persist(e3);  
      
    t.commit();  
    session.close();  
    System.out.println("success");  
}  
}  