package com.jackrutorial.model;

import javax.persistence.*;
import java.util.Objects;

/**
 * The User Entity class
 *
 * @author ibrahim KARAYEL
 * @version 1.0
 * Date 4/27/2018.
 */
@Entity
@Table(name = "user", schema = "tododb")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "custId", unique = true)
    private int CustomerId;

    @Column(name = "user_name")
    private String username;

    @Column(name = "password")
    private String password;

    @Column(name = "user_role")
    private int UserRole;

    public User() {
    }


    
    
    
    public User(int customerId, String username, String password, int userRole) {
		super();
		CustomerId = customerId;
		this.username = username;
		this.password = password;
		UserRole = userRole;
	}


	public int getCustomerId() {
		return CustomerId;
	}





	public void setCustomerId(int customerId) {
		CustomerId = customerId;
	}





	public String getUsername() {
		return username;
	}





	public void setUsername(String username) {
		this.username = username;
	}





	public String getPassword() {
		return password;
	}





	public void setPassword(String password) {
		this.password = password;
	}





	public int getUserRole() {
		return UserRole;
	}





	public void setUserRole(int userRole) {
		UserRole = userRole;
	}





	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return CustomerId == user.CustomerId &&
                Objects.equals(username, user.username) &&
                Objects.equals(password, user.password) &&
                Objects.equals(UserRole, user.UserRole);
    }

    
}
