package com.cmt.service;

import com.cmt.dao.AccountNotFoundException;


public interface AccountService {
	float calculateInterest(int accno)throws AccountNotFoundException, ProcessingException;
}
