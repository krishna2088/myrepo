package com.cmt.aop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	
	@SuppressWarnings("resource")
	public static void main(String[] args)  {
		
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		College operation= applicationContext.getBean("operation", College.class);
		operation.getName();
		operation.getCollege();
		
		
		/*Student student= applicationContext.getBean("student", Student.class);
		System.out.println(student.getName());
		*/
	
	}

}




/*
 * Student operation1= applicationContext.getBean("student", Student.class);
		operation1.getName();
 */
