package com.cmt.aop;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class CollegeAspect {

	@Before("@annotation(com.cmt.aop.Security)")
	    public void collegeAdvice()  
	    {  
			 System.out.println("General");  
	    } 
	    
}

///@Before("@annotation(com.cmt.aop.Security)")