package com.cmt.service;

public class ProcessingException extends Exception{

}
