package com.cmt.aop;

public class Student {
	
	String name;

	public String getName() {
		System.out.println("Student");
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
