package com.cmt.spring;

public class CustomerService {
	public void processService(){
		System.out.println("CustomerService: service processed");
	}
}
