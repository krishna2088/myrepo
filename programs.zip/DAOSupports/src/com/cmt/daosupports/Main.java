package com.cmt.daosupports;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		AccountDAO dao = ctx.getBean("dao", AccountDAO.class);
		
		Account account = new Account(111, "Lalith", 150);
		  dao.insert(account);
//		  dao.delete(account);
		  System.out.println("account details inserted successfully.");
	}

}
