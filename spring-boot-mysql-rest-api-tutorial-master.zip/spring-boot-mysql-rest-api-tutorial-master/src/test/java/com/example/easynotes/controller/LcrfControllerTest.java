package com.example.easynotes.controller;

import static org.junit.Assert.*;

import org.junit.Test;

public class LcrfControllerTest {

	@Test
	public void testGetAll() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetSellerDetail() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetDataByIdAndName() {
		fail("Not yet implemented");
	}

}
