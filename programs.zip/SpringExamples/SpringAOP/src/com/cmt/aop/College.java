package com.cmt.aop;

public class College {
	
	String name;	
	
	@Security
	public int  getName() {
		System.out.println("get");
		return 1;
	}
	
	
	public void setName(String name) {
		this.name = name;
	}
	@Security
	public String getCollege() {
		System.out.println("Hi");
		return "";
	}
	
	public void message() {
		System.out.println("msg method invoked");
	}
}
