package com.cmt.service;

import com.cmt.dao.Account;
import com.cmt.dao.AccountDAOInterface;
import com.cmt.dao.AccountNotFoundException;
import com.cmt.dao.DataAccessException;

public class AccountServiceBean implements AccountService{
	
	AccountDAOInterface dao; 
	
	public void setDao(AccountDAOInterface dao) {
		this.dao = dao;
	}
	
	@Override
	public float calculateInterest(int accno) throws AccountNotFoundException,
			ProcessingException {
		float interest = 0.0f;
		try{
			
			Account acc = dao.getAccount(accno);
			float balance = acc.getBalance();
			interest = balance*0.8f;
		}catch(AccountNotFoundException e){
			
				throw e;
		} catch(DataAccessException e){
			
			throw new ProcessingException();
		}	
		return interest;
	}
}
