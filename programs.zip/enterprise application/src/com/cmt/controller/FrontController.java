package com.cmt.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cmt.dao.AccountNotFoundException;
import com.cmt.service.ProcessingException;

public class FrontController extends HttpServlet {

//	BeanFactory factory;
	ApplicationContext factory;
	public void init() throws ServletException{
		
//		factory =  new XmlBeanFactory(new ClassPathResource("beans.xml"));
		factory = new ClassPathXmlApplicationContext("beans.xml");
		
	}
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)throws IOException, ServletException{
		
		String responsepage = "view.jsp";
		AccountController controller = factory.getBean("controller", AccountController.class);
		try{
			
			controller.execute(request);
			
		}catch(AccountNotFoundException e){
			
			responsepage = "noaccount.jsp";
		} catch (ProcessingException e) {
			
			responsepage = "exception.jsp"; //
		}catch( NumberFormatException e){
			
			responsepage = "enteraccno.jsp";
		}
		
		request.getRequestDispatcher(responsepage).forward(request, response);
	}
}
