package com.cmt.daosupports;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.transaction.annotation.Transactional;

public class AccountDAO extends JdbcDaoSupport {

	
	public void insert(Account account) {

		String sql = "INSERT INTO account VALUES (?, ?, ?)";

		getJdbcTemplate().update(sql, new Object[] { account.getAccno(), account.getName(),	account.getBalance() });
	}
	
	/*public void delete(Account account) {

		String sql = "delete from account where balance = ?";

		getJdbcTemplate().update(sql, new Object[] {account.getBalance() });
	}*/
}
