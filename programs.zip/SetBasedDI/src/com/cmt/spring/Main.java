package com.cmt.spring;

import java.util.List;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	static int count = 0;
	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		College college= (College)applicationContext.getBean("college");
		Set<Student>	students = college.getStudents();
		
		for(Student s : students){
	
			s.displayStudentDetails();
			
			count++;
		}
		System.out.println("count :"+ count);
	}
}
