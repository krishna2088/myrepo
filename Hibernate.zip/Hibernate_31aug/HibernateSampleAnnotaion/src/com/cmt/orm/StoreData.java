package com.cmt.orm;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class StoreData {
	public static void main(String[] args) {
		
		/*
		// creating seession factory object
		SessionFactory factory = cfg.buildSessionFactory();

		// creating session object
		Session session = factory.openSession();
		*/
		Configuration configuration = new Configuration();
		configuration.configure();
		
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
		SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry );
		
		Session session = sessionFactory.openSession();
		Transaction t = session.beginTransaction();

		Employee e1 = new Employee();
		e1.setId(1001);
		e1.setFirstName("Vimala");
		e1.setLastName("Karthikan");

		Employee e2 = new Employee();
		e2.setId(1002);
		e2.setFirstName("Ram");
		e2.setLastName("Rajan");

		session.persist(e1);
		session.persist(e2);

		t.commit();
		session.flush();
		session.close();
		sessionFactory.close();
		System.out.println("successfully saved");
	}
}