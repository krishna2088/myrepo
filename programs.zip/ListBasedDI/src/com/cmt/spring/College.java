package com.cmt.spring;

import java.util.List;

public class College {
	
	private String name;
	private  List<Student> students;
	
	public College(){}
	
	public College(String name){
		this.name = name;
	}
	
	public List<Student> getStudents() {
		return students;
	}
	public void setStudents(List<Student> students) {
		this.students = students;
	}
}
