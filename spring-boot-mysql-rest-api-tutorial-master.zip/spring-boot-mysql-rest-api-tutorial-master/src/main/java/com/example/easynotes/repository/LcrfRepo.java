package com.example.easynotes.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.easynotes.model.LcrfApi;

@Repository
public interface LcrfRepo extends JpaRepository<LcrfApi, Long>{
	
	@Query(
            value = "SELECT * FROM HSBC WHERE Seller_Id = :sellerId",
            nativeQuery = true
    )
	public LcrfApi getSellerDataById(@Param("sellerId")long sellerId);
	
	
	@Query(
            value = "SELECT * FROM HSBC WHERE Seller_Id = :sellerId and Seller_Name =:sellerName",
            nativeQuery = true
    )
	public List<LcrfApi> findDataBySellerIDAndSellerName(long sellerId, String sellerName);

}
