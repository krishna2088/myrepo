package com.cmt.orm;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class UserDao {

	public static String register(User u) {
		
		String i = null;
		Session session = new Configuration().configure().buildSessionFactory()
				.openSession();

		Transaction t = session.beginTransaction();
		t.begin();
		
		try{
			i = (String) session.save(u).toString();

			t.commit();
		}catch (Exception e){ 
			return i;
		}
		
		session.close();

		return i;
	}

}
