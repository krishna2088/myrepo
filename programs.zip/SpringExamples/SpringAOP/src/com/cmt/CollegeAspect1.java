package com.cmt;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class CollegeAspect1 {

	    @Before("allGetters()")  
	    public void collegeAdvice()  
	    {  
	        System.out.println("collegeAdvice concern");  
	    }  
	    
	    @Before("allCollege()")
	    public void collegeAdvice2()  
	    {  
	        System.out.println("collegeAdvice_2 concern");  
	    }  
	    
	    @Pointcut("execution(public * get*())")
	    public void allGetters(){}
	    
	    @Pointcut("within(com.cmt.aop.College)")
	    public void allCollege(){}
	}  

