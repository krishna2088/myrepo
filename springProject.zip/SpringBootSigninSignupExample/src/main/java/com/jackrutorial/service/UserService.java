package com.jackrutorial.service;



import java.util.Collection;

import com.jackrutorial.model.User;

/**
 * The UserService interface
 *
 * @author ibrahim KARAYEL
 * @version 1.0
 * Date 4/27/2018.
 */
public interface UserService {

    User save(User user);

    User update(User user);

    User findByUserName(String username);

    User findByRole(String UserRole);

    Collection<User> findAll();
}
