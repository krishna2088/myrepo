package com.cmt.aop;

public @interface Security {

}
