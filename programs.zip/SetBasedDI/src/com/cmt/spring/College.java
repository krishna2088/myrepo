package com.cmt.spring;

import java.util.List;
import java.util.Set;

public class College {
	
	private String name;
	private  Set<Student> students;
	
	public College(){}
	
	public College(String name){
		this.name = name;
	}
	
	public Set<Student> getStudents() {
		return students;
	}
	public void setStudents(Set<Student> students) {
		this.students = students;
	}
}
